#!/bin/bash

MININDN_DIR="/home/osboxes/mini-ndn"

cd $MININDN_DIR/ndn-cxx/; sudo ./waf
