#!/bin/bash

# nfdc face create udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add vehicle udp://10.0.0.7
nfdc route add controladddrone udp://10.0.0.7
nfdc route add controladdsensor udp://10.0.0.7
nfdc route add controladdhuman udp://10.0.0.7
nfdc route add controladdvehicle udp://10.0.0.7
nfdc face create udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add vehicle udp://10.0.0.7
nfdc route add controladddrone udp://10.0.0.7
nfdc route add controladdsensor udp://10.0.0.7
nfdc route add controladdhuman udp://10.0.0.7
nfdc route add controladdvehicle udp://10.0.0.7
nfdc face create udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add vehicle udp://10.0.0.7
nfdc route add controladddrone udp://10.0.0.7
nfdc route add controladdsensor udp://10.0.0.7
nfdc route add controladdhuman udp://10.0.0.7
nfdc route add controladdvehicle udp://10.0.0.7
nfdc face create udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add vehicle udp://10.0.0.7
nfdc route add controladddrone udp://10.0.0.7
nfdc route add controladdsensor udp://10.0.0.7
nfdc route add controladdhuman udp://10.0.0.7
nfdc route add controladdvehicle udp://10.0.0.7
nfdc face create udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add vehicle udp://10.0.0.7
nfdc route add controladddrone udp://10.0.0.7
nfdc route add controladdsensor udp://10.0.0.7
nfdc route add controladdhuman udp://10.0.0.7
nfdc route add controladdvehicle udp://10.0.0.7
nfdc face create udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add vehicle udp://10.0.0.7
nfdc route add controladddrone udp://10.0.0.7
nfdc route add controladdsensor udp://10.0.0.7
nfdc route add controladdhuman udp://10.0.0.7
nfdc route add controladdvehicle udp://10.0.0.7
nfdc face create udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add drone udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add sensor udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add human udp://10.0.0.7
nfdc route add vehicle udp://10.0.0.7
nfdc route add controladddrone udp://10.0.0.7
nfdc route add controladdsensor udp://10.0.0.7
nfdc route add controladdhuman udp://10.0.0.7
nfdc route add controladdvehicle udp://10.0.0.7